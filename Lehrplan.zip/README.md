Lehrplan
========

Lehrplan es un app en etapa de desarrollo para Firefox OS bajo la licencia gpl 2.0 de la FSF, en el cual su objetivo final es poder dar a los estudiantes de educación superior un control propio de su malla curricular y las notas de estas.

## Intalación ##

Para instalar la app en necesario tener instalado el emulador de firefox OS integrado con el navegador firefox, luego debe dirigirse al apartado para añadir una nueva aplicación empaquetada, ahi seleccionara la carpeta Lehrplan del directorio donde descargo el repositorio, y presione aceptar y ya tendra Lehrplan instalado em su emulador para testing. 

